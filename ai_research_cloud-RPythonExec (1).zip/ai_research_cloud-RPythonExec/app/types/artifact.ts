export interface BoltArtifactData {
  id: string;
  title: string;
}
