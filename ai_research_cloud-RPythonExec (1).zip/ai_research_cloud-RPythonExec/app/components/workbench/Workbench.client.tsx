import { useStore } from '@nanostores/react';
import { motion, type HTMLMotionProps, type Variants } from 'framer-motion';
import { computed } from 'nanostores';
import { memo, useCallback, useEffect } from 'react';
import { toast } from 'react-toastify';
import {
  type OnChangeCallback as OnEditorChange,
  type OnScrollCallback as OnEditorScroll,
} from '~/components/editor/codemirror/CodeMirrorEditor';
import { IconButton } from '~/components/ui/IconButton';
import { PanelHeaderButton } from '~/components/ui/PanelHeaderButton';
import { Slider, type SliderOptions } from '~/components/ui/Slider';
import { workbenchStore, type WorkbenchViewType } from '~/lib/stores/workbench';
import { classNames } from '~/utils/classNames';
import { cubicEasingFn } from '~/utils/easings';
import { renderLogger } from '~/utils/logger';
import { EditorPanel } from './EditorPanel';
import { Preview } from './Preview';
import { PyExec } from './PyExec';
import { EngineeringWork } from './EngineeringWork';
import { ImageMergeTo3D } from './ImageMergeTo3D';
import { RExec } from './RExec';
import { MathlibExec } from './MathlibExec';
import { chatStore } from '~/lib/stores/chat';

interface WorkspaceProps {
  chatStarted?: boolean;
  isStreaming?: boolean;
  projectType?: string;
}

const viewTransition = { ease: cubicEasingFn };

const sliderOptions: SliderOptions<WorkbenchViewType> = {
  left: {
    value: 'code',
    text: 'Code',
  },
  middle: {
    value: 'executor',
    text: (selectedFile?: string, projectType?: string) => {
      if (projectType?.toLowerCase() === 'engineering') return 'Engineer';
      if (projectType?.toLowerCase() === 'r') return 'R';
      if (projectType?.toLowerCase() === 'mathlib') return 'Mathlib';
      if (projectType?.toLowerCase() === '2d23d') return '3D合成';
      return 'Python';
    },
    show: (selectedFile?: string, projectType?: string) => {
      if (!selectedFile) return false;
      if (projectType?.toLowerCase() === 'engineering') return true;
      return ['python', 'r', 'mathlib'].includes(projectType?.toLowerCase() || '') &&
             (selectedFile.endsWith('.py') || selectedFile.endsWith('.r') || selectedFile.endsWith('.m'));
    },
  },
  right: {
    value: 'preview',
    text: 'Preview',
    show: (selectedFile?: string, projectType?: string) => {
      return projectType?.toLowerCase() !== 'engineering';
    },
  },
};

const workbenchVariants = {
  closed: {
    width: 0,
    transition: {
      duration: 0.2,
      ease: cubicEasingFn,
    },
  },
  open: {
    width: 'var(--workbench-width)',
    transition: {
      duration: 0.2,
      ease: cubicEasingFn,
    },
  },
} satisfies Variants;

export const Workbench = memo(({ chatStarted, isStreaming, projectType }: WorkspaceProps) => {
  renderLogger.trace('Workbench');

  const hasPreview = useStore(computed(workbenchStore.previews, (previews) => previews.length > 0));
  const showWorkbench = useStore(workbenchStore.showWorkbench);
  const selectedFile = useStore(workbenchStore.selectedFile);
  const currentDocument = useStore(workbenchStore.currentDocument);
  const unsavedFiles = useStore(workbenchStore.unsavedFiles);
  const files = useStore(workbenchStore.files);
  const selectedView = useStore(workbenchStore.currentView);

  const setSelectedView = (view: WorkbenchViewType) => {
    workbenchStore.currentView.set(view);
  };

  useEffect(() => {
    if (hasPreview) {
      setSelectedView('preview');
    }
  }, [hasPreview]);

  useEffect(() => {
    workbenchStore.setDocuments(files);
  }, [files]);

  const onEditorChange = useCallback<OnEditorChange>((update) => {
    workbenchStore.setCurrentDocumentContent(update.content);
  }, []);

  const onEditorScroll = useCallback<OnEditorScroll>((position) => {
    workbenchStore.setCurrentDocumentScrollPosition(position);
  }, []);

  const onFileSelect = useCallback((filePath: string | undefined) => {
    workbenchStore.setSelectedFile(filePath);
    console.log('======filesCount====', workbenchStore.filesStore.filesCount);
  }, []);

  const onFileSave = useCallback(() => {
    workbenchStore.saveCurrentDocument().catch(() => {
      toast.error('Failed to update file content');
    });
  }, []);

  const onFileReset = useCallback(() => {
    workbenchStore.resetCurrentDocument();
  }, []);

  const handleErrorFix = useCallback((errorMessage: string) => {
    const message = `请修复下列错误:\n${errorMessage}`;
    chatStore.setKey('pendingMessage', message);
  }, []);

  return (
    chatStarted && (
      <motion.div
        initial="closed"
        animate={showWorkbench ? 'open' : 'closed'}
        variants={workbenchVariants}
        className="z-workbench"
      >
        <div
          className={classNames(
            'fixed top-[calc(var(--header-height)+1.5rem)] bottom-6 w-[var(--workbench-inner-width)] mr-4 z-0 transition-[left,width] duration-200 bolt-ease-cubic-bezier',
            {
              'left-[var(--workbench-left)]': showWorkbench,
              'left-[100%]': !showWorkbench,
            },
          )}
        >
          <div className="absolute inset-0 px-6">
            <div className="h-full flex flex-col bg-bolt-elements-background-depth-2 border border-bolt-elements-borderColor shadow-sm rounded-lg overflow-hidden">
              <div className="flex items-center px-3 py-2 border-b border-bolt-elements-borderColor">
                <Slider selected={selectedView} options={sliderOptions} setSelected={setSelectedView} projectType={projectType}/>
                <div className="ml-auto" />
                {selectedView === 'code' && (
                  <PanelHeaderButton
                    className="mr-1 text-sm"
                    onClick={() => {
                      workbenchStore.toggleTerminal(!workbenchStore.showTerminal.get());
                    }}
                  >
                    <div className="i-ph:terminal" />
                    Toggle Terminal
                  </PanelHeaderButton>
                )}
                <IconButton
                  icon="i-ph:x-circle"
                  className="-mr-1"
                  size="xl"
                  onClick={() => {
                    workbenchStore.showWorkbench.set(false);
                  }}
                />
              </div>
              <div className="relative flex-1 overflow-hidden">
                <View
                  initial={{ x: selectedView === 'code' ? 0 : '-100%' }}
                  animate={{ x: selectedView === 'code' ? 0 : '-100%' }}
                >
                 
                    <EditorPanel
                      editorDocument={currentDocument}
                      isStreaming={isStreaming}
                      selectedFile={selectedFile}
                      files={files}
                      unsavedFiles={unsavedFiles}
                      onFileSelect={onFileSelect}
                      onEditorScroll={onEditorScroll}
                      onEditorChange={onEditorChange}
                      onFileSave={onFileSave}
                      onFileReset={onFileReset}
                    />
             
                </View>
                <View
                  initial={{ x: selectedView === 'executor' ? 0 : '100%' }}
                  animate={{ x: selectedView === 'executor' ? 0 : '100%' }}
                >
                  {projectType?.toLowerCase() === 'python' && <PyExec filename={selectedFile} />}
                  {projectType?.toLowerCase() === 'r' && <RExec filename={selectedFile} onRequestFix={handleErrorFix} />}
                  {projectType?.toLowerCase() === 'mathlib' && <MathlibExec filename={selectedFile} />}
                  {projectType?.toLowerCase() === 'engineering' && <EngineeringWork filesStore={workbenchStore.filesStore} fileCount={workbenchStore.filesStore.filesCount}/>}
                  {projectType?.toLowerCase() === '2d23d' && (
                    <ImageMergeTo3D filesStore={workbenchStore.filesStore} fileCount={workbenchStore.filesStore.filesCount}/>
                  )}
                </View>
                <View
                  initial={{ x: selectedView === 'preview' ? 0 : '100%' }}
                  animate={{ x: selectedView === 'preview' ? 0 : '100%' }}
                >
                  {projectType?.toLowerCase() !== 'engineering' ? <Preview /> : null}
                </View>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    )
  );
});

interface ViewProps extends HTMLMotionProps<'div'> {
  children: JSX.Element | JSX.Element[];
}

const View = memo(({ children, ...props }: ViewProps) => {
  return (
    <motion.div className="absolute inset-0" transition={viewTransition} {...props}>
      {children}
    </motion.div>
  );
});
